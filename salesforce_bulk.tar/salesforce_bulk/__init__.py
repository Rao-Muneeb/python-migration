from .salesforce_bulk import SalesforceBulk
from .csv_adapter import CsvDictsAdapter

__version__ = '1.0.7'
